AB Electronics UK IO Pi C++ Library Unit Tests
=====

This folder contains unit tests for each method in the IO Pi library.  
Most of the tests require a logic analyser connected to the SDA and SCL pins on the Raspberry Pi GPIO header.